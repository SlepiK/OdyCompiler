#ifndef SIERRA_ODYPLAN_V3_BASIC_OPERATORS_PIPE_JOIN_PHYSICAL_DETAILS_JOIN_BUFFER_HPP
#define SIERRA_ODYPLAN_V3_BASIC_OPERATORS_PIPE_JOIN_PHYSICAL_DETAILS_JOIN_BUFFER_HPP
#include <basic/operators/pipe/join/physical/details/join_side.h>
#include <chrono>
#include <mutex>

namespace sierra::odyplan::v3::basic::operators::pipe::join::physical::details {
    class JoinBuffer {
    public:
        struct RetainPointer {
            core::shared::types::ValueTypeId typeId;
            void* ptr;
        };

        struct JoinSnapshot {
            bool wasLeft = false;
            std::vector<std::byte> data;
            std::vector<std::uint64_t> fieldOffsets;
            std::vector<core::shared::types::ValueTypeId> fieldTypeIds;
            Timestamp startTs;
            Timestamp endTs;
            std::int64_t startTb;
            std::int64_t endTb;

            std::vector<std::byte> candidateData;
            std::vector<Timestamp> candidateStarts;
            std::vector<Timestamp> candidateEnds;
            std::vector<std::int64_t> candidateStartsTb;
            std::vector<std::int64_t> candidateEndsTb;
            std::vector<std::uint64_t> candidateFieldOffsets;
            std::vector<core::shared::types::ValueTypeId> candidateFieldTypeIds;
            std::size_t candidateRowByteSize = 0;
            std::size_t candidateCount = 0;

            std::vector<RetainPointer> retainPointers;
            const core::runtime::types::RuntimeTypeRegistry* runtimeTypeRegistry = nullptr;

            std::vector<std::size_t> markedForRemove;
            bool isExtraction = false;

            std::vector<std::size_t> matchIndicies;

            [[nodiscard]] const std::byte* ownFieldPtr(std::size_t fieldIdx) const;

            [[nodiscard]] const std::byte* candidateFieldPtr(std::size_t candidateIdx, std::size_t fieldIdx) const;
        };

        JoinBuffer(core::logical::port::Port leftSchema,
                   core::logical::port::Port rightSchema,
                   const core::runtime::types::RuntimeTypeRegistry* runtimeTypeRegistry);

        ~JoinBuffer();

        JoinBuffer(const JoinBuffer&) = delete;
        JoinBuffer& operator=(const JoinBuffer&) = delete;
        JoinBuffer(JoinBuffer&&) = delete;
        JoinBuffer& operator=(JoinBuffer&&) = delete;

        void close();

        void lock();

        void unlock();

        void beginLeft();

        void beginRight();

        auto pushLeft(std::size_t index, const void* data) -> void;

        void pushRight(std::size_t index, const void* data);

        void endLeft(Timestamp startTs, Timestamp endTs, std::int64_t startTb, std::int64_t endTb);

        void endRight(Timestamp startTs, Timestamp endTs, std::int64_t startTb, std::int64_t endTb);

        void matchLeft(Timestamp startTs, Timestamp endTs, std::int64_t startTb, std::int64_t endTb);

        void matchRight(Timestamp startTs, Timestamp endTs, std::int64_t startTb, std::int64_t endTb);

        // NOLINTNEXTLINE(cppcoreguidelines-owning-memory)
        JoinSnapshot* snapshotForCompute(bool callFromLeft, bool extract);

        static void releaseSnapshot(JoinSnapshot* snapshot);

        void enableEqui(const std::vector<std::size_t>& leftFieldIndices,
                        const std::vector<std::size_t>& rightFieldIndices,
                        const std::vector<core::shared::types::ValueTypeId>& keyTypeIds);

        void evict(Timestamp threshold, bool callFromLeft, bool isFinal);

        void markCandidateForRemove(JoinSnapshot *snapshot, std::size_t candidateIdx);

        void markCandidateAsMatch(JoinSnapshot *snapshot, std::size_t candidateIdx);

        void markAllCandidateAsMatch(JoinSnapshot *snapshot, bool extract);

        void removeMarkedCandidates(JoinSnapshot *snapshot, bool wasLeft);

    private:
        JoinSide mLeftSide;
        JoinSide mRightSide;
        std::mutex mMutex;
        const core::runtime::types::RuntimeTypeRegistry* mRuntimeTypeRegistry;

        std::vector<std::size_t> mCandidates;
        bool mAllReleased = false;

        void matchAgainst(const JoinSide& sourceSide, JoinSide& otherSide, const std::vector<std::uint64_t>& sourceKeyFieldIndices, Timestamp sourceStartTs, Timestamp sourceEndTs, bool extract);


        void copyRowIntoSnapshot(const JoinSide& side, std::uint64_t rowIndex, std::vector<std::byte>& dst, std::size_t dstOffset,
                                 std::vector<std::size_t>& offsetsOut, std::vector<core::shared::types::ValueTypeId>& typeIdsOut,
                                 std::vector<RetainPointer>& retainedOut) const;
    };
}  // namespace sierra::odyplan::v3::basic::operators::pipe::join::physical::details

#endif  // SIERRA_ODYPLAN_V3_BASIC_OPERATORS_PIPE_JOIN_PHYSICAL_DETAILS_JOIN_BUFFER_HPP