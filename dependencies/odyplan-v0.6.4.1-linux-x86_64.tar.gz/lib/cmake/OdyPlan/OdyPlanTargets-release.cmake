#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "odyplan::core" for configuration "Release"
set_property(TARGET odyplan::core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(odyplan::core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libodyplan_core.a"
  )

list(APPEND _cmake_import_check_targets odyplan::core )
list(APPEND _cmake_import_check_files_for_odyplan::core "${_IMPORT_PREFIX}/lib/libodyplan_core.a" )

# Import target "odyplan::basic" for configuration "Release"
set_property(TARGET odyplan::basic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(odyplan::basic PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libodyplan_basic.a"
  )

list(APPEND _cmake_import_check_targets odyplan::basic )
list(APPEND _cmake_import_check_files_for_odyplan::basic "${_IMPORT_PREFIX}/lib/libodyplan_basic.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
